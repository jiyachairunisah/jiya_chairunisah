ESSAY 2 - DATA WAREHOUSE

-- Create dimension tables

CREATE TABLE dim_user (
user_id INT PRIMARY KEY,
user_name VARCHAR(100),
country VARCHAR(50)
);
CREATE TABLE dim_post (
post_id INT PRIMARY KEY,
post_text VARCHAR(500),
post_date DATE,
user_id INT,
FOREIGN KEY (user_id) REFERENCES dim_user(user_id)
);
CREATE TABLE dim_date (
date_id INT PRIMARY KEY,
full_date DATE,
year INT,
month INT,
day INT
);
CREATE TABLE dim_like (
like_id INT PRIMARY KEY,
user_id INT,
post_id INT,
like_date DATE,
FOREIGN KEY (user_id) REFERENCES dim_user(user_id),
FOREIGN KEY (post_id) REFERENCES dim_post(post_id)
);

INSERT INTO fact_post_performance (post_id, date_id, views, likes)
SELECT
    p.post_id,
    date(p.post_date) AS date_id,
    COUNT(DISTINCT v.user_id) AS views,
    COUNT(DISTINCT l.user_id) AS likes
FROM raw_posts p
LEFT JOIN raw_likes l ON p.post_id = l.post_id
LEFT JOIN (
    SELECT post_id, user_id
    FROM raw_likes
    GROUP BY post_id, user_id ) AS v ON p.post_id = v.post_id
GROUP BY p.post_id, date(p.post_date);

-- Create fact tables

CREATE TABLE fact_post_performance (
performance_id SERIAL PRIMARY KEY,
post_id INT,
date_id INT,
total_likes INT,
FOREIGN KEY (post_id) REFERENCES dim_post(post_id),
FOREIGN KEY (date_id) REFERENCES dim_date(date_id)
);
CREATE TABLE fact_daily_posts (
daily_post_id SERIAL PRIMARY KEY,
date_id INT,
user_id INT,
total_posts INT,
FOREIGN KEY (date_id) REFERENCES dim_date(date_id),
FOREIGN KEY (user_id) REFERENCES dim_user(user_id)
);